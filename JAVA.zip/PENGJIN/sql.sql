
create table Salle (
	id_salle BIGSERIAL NOT NULL PRIMARY KEY,
	nom_salle VARCHAR(50) NOT NULL,
	cap_salle bigint NOT NULL,
	type VARCHAR(50) NOT NULL
	);

insert into Salle (nom_salle,cap_salle ,type ) values ('B314',50,INFO);

create table groupe (
	id_groupe BIGSERIAL NOT NULL PRIMARY KEY,
	nom_groupe VARCHAR(50) NOT NULL,
	nombre_eleve bigint NOT NULL,
	max_heure bigint NOT NULL,
	select_heure bigint
	);

insert into groupe (nom_groupe,nombre_eleve ,max_heure) values ('groupe1',20 , 30);

create table maitere (
	id_matiere BIGSERIAL NOT NULL PRIMARY KEY,
	nom_matiere VARCHAR(50) NOT NULL,
	num_heure bigint NOT NULL
	);

insert into maitere (nom_matiere,num_heure ) values ('MATH',15);

create table professeur (
	id_prof BIGSERIAL NOT NULL PRIMARY KEY,
	nom_prof VARCHAR(50) NOT NULL,
	max_prof bigint NOT NULL,
	mat_prof VARCHAR(50) NOT NULL,
	indi_prof VARCHAR(50) NOT NULL
	);
insert into professeur (nom_prof,max_prof,mat_prof ) values ('ABC',30, 'MATH');

create table cours(
	id_cour BIGSERIAL NOT NULL PRIMARY KEY,
	date_cour VARCHAR(50) NOT NULL,
	matier_cour VARCHAR(50) NOT NULL,
	group_cour VARCHAR(50) NOT NULL,
	prof_cour VARCHAR(50) NOT NULL,
	salle_cour varchar(50) NOT NULL
	)

insert into cours (date_cour,matier_cour,group_cour, prof_cour,salle_cour) values ('8:00','MATH','groupe1','ABC','B314');