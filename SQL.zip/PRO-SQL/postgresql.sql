


create table client (
	id_client BIGSERIAL NOT NULL PRIMARY KEY,
	name_client VARCHAR(50) NOT NULL,
	adress_client VARCHAR(50) NOT NULL
	);


insert into client (name_client, adress_client) values ('Dilley', '7 Superior Hill');
insert into client (name_client, adress_client) values ('Casino', '62313 Waxwing Way');
insert into client (name_client, adress_client) values ('Mattosoff', '3519 Thackeray Plaza');
insert into client (name_client, adress_client) values ('Stead', '2 Pleasure Road');
insert into client (name_client, adress_client) values ('Tremblay', '459 Coleman Park');
insert into client (name_client, adress_client) values ('Gricks', '00852 Lighthouse Bay Pass');
insert into client (name_client, adress_client) values ('Kilty', '245 Birchwood Crossing');
insert into client (name_client, adress_client) values ('Toye', '7550 Namekagon Avenue');
insert into client (name_client, adress_client) values ('Skipsea', '7283 Center Hill');
insert into client (name_client, adress_client) values ('Gillbee', '8 Macpherson Road');

	

create table marchandise (
	id_march BIGSERIAL NOT NULL PRIMARY KEY,
	type_march VARCHAR(50) NOT NULL,
	nombre_march VARCHAR(50) NOT NULL
	);


insert into marchandise (type_march, nombre_march) values ('essences','20 m3');
insert into marchandise (type_march, nombre_march) values ('bois','10steres');
insert into marchandise (type_march, nombre_march) values ('voiture','30');


create table wagon (
	id_wagon BIGSERIAL NOT NULL PRIMARY KEY,
	capacite_wagon VARCHAR(50) NOT NULL,
	chargement_wagon VARCHAR(50) NOT NULL,
	train_wagon integer NOT NULL
	);

insert into wagon (chargement_wagon, capacite_wagon,train_wagon) values ('essences','50 m3',1);
insert into wagon (chargement_wagon, capacite_wagon,train_wagon) values ('bois','50steres',2);
insert into wagon (chargement_wagon, capacite_wagon, train_wagon) values ('vroiture','50',3);

create table train(
	id_train BIGSERIAL NOT NULL PRIMARY KEY,
	arrete_trian VARCHAR(50) NOT NULL,
	date_train VARCHAR(50) NOT NULL
	);


insert into train (arrete_trian, date_train) values ('Angers','2021/12/10');
insert into train (arrete_trian, date_train) values ('Paris','2021/12/14');



create table ferroviaire(
	id_fer BIGSERIAL NOT NULL PRIMARY KEY,
	reaseau_fer VARCHAR(50) NOT NULL,
	gare_fer VARCHAR(50) NOT NULL
	);

insert into ferroviaire (reaseau_fer, gare_fer) values ('Nante-Angers-Paris','Nante');
insert into ferroviaire (reaseau_fer, gare_fer) values ('Nante-Angers-Paris','Angers');
insert into ferroviaire (reaseau_fer, gare_fer) values ('Nante-Angers-Paris','Paris');




CREATE or REPLACE VIEW manage AS
SELECT * FROM train
FULL JOIN wagon  ON train_wagon = id_train;



CREATE TABLE client_audits (
   id serial primary key,
   client_id int NOT NULL,
   name_client varchar(40) NOT NULL,
   new_name varchar(40) NOT NULL
);




CREATE OR REPLACE FUNCTION log_name_changes()
  RETURNS trigger AS
$BODY$
BEGIN
 IF NEW.name_client <> OLD.name_client THEN
 INSERT INTO client_audits(client_id,name_client,new_name)
 VALUES(OLD.id_client,OLD.name_client,NEW.name_client);
 END IF;

 RETURN NEW;
END;
$BODY$

LANGUAGE plpgsql VOLATILE -- Says the function is implemented in the plpgsql language; VOLATILE says the function has side effects.
COST 100; -- Estimated execution cost of the function.




CREATE TRIGGER name_changes
  BEFORE UPDATE
  ON client
  FOR EACH ROW
  EXECUTE PROCEDURE log_name_changes();