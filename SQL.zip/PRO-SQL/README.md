     La couche DAO implémente l'instruction SQL
     la couche modele implémente les bases des classes
     La couche util réalise la connexion à la base de données
     La couche view pour implémenter le swing par windowsbuilders

1. chemin de construction du fichier de base de données postgresql-42.3.1.jar
2. Ouvrez pgadmin, créez la base de données : GDT_SQL
    Charger l'instruction postgresql.sql
3. package util, dbUtil.java se connecte à la base de données
    Confirmez que l'adresse, le nom d'utilisateur et le mot de passe sont corrects
4. voir pacakge, lanceur indexFrame


Opérations de base sur la barre de menu supérieure

Utiliser l'exception dans le package DAO

Utiliser l'view dans le indexFrame button "check Train-Wagon" 
et postgresql.sql line 72~83

J'utilise Trigger pour créer une nouvelle fenêtre pour enregistrer l'historique des modifications du client
et postgresql.sql line 88~111

Dao: baseDao.java est la classe parente publique
     createXXX ： create
     updateXXX :  update
     deleteXXX ： delete
     readXXX : find
     listXXX : find ALL
     viewDao : view sql statement

Il n'y a que des commentaires dans le package Client

model: les bases des classes
       View : view sql class
       clientAudit : trigger  nregistrer l'historique des modifications du client

util :  connect database postgresql

view : Gui swing windowsBuilders




     